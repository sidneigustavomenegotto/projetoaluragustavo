const caixaPrincipal = document.querySelector(".caixa-principal");
const caixaPerguntas = document.querySelector(".caixa-perguntas");
const caixaAlternativas = document.querySelector(".caixa-alternativas");
const caixaResultado = document.querySelector(".caixa-resultado");
const textoResultado = document.querySelector(".texto-resultado");

const perguntas = [
    {
        enunciado: "O que realmente interessa na sua vida?",
        alternativas: [
            { texto: "Viver", proxima: 1 },
            { texto: "Trabalhar", proxima: 2 }
        ]
    },
    {
        enunciado: "Como ser saudável?",
        alternativas: [
            { texto: "Plano de saúde", proxima: -1 },
            { texto: "Academia", proxima: -1 }
        ]
    },
    {
        enunciado: "Com o que eu gostaria de trabalhar?",
        alternativas: [
            { texto: "Agronomia", proxima: -1 },
            { texto: "Caminhoneiro", proxima: -1 }
        ]
    }
];

let atual = 0;

function mostraPergunta() {
    caixaAlternativas.innerHTML = ""; // Limpar alternativas anteriores
    const perguntaAtual = perguntas[atual];
    caixaPerguntas.textContent = perguntaAtual.enunciado;
    mostraAlternativas(perguntaAtual.alternativas);
}

function mostraAlternativas(alternativas) {
    for (const alternativa of alternativas) {
        const botaoAlternativa = document.createElement("button");
        botaoAlternativa.textContent = alternativa.texto;
        botaoAlternativa.addEventListener("click", () => respostaSelecionada(alternativa.proxima));
        caixaAlternativas.appendChild(botaoAlternativa);
    }
}

function respostaSelecionada(proximaPergunta) {
    if (proximaPergunta === -1) {
        // Caso final (não há mais perguntas)
        caixaPerguntas.textContent = "Fim da pesquisa!";
        caixaAlternativas.innerHTML = "";
    } else {
        atual = proximaPergunta;
        mostraPergunta();
    }
}

mostraPergunta();
